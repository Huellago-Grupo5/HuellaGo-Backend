package pe.edu.upc.luchalibre.dtos;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upc.luchalibre.entities.TipoLucha;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LuchaDTO {

    private Long id;
    private Integer ordenCartelera;
    private String tipoLucha;
    private Integer minParticipantes;
    private Integer duracionMinutos;
    private Boolean estelar;
    private Long eventoId;

}
