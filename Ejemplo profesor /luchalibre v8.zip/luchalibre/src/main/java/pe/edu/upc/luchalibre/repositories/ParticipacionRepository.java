package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pe.edu.upc.luchalibre.dtos.ParticipacionDTO;
import pe.edu.upc.luchalibre.entities.Participacion;

import java.util.List;

public interface ParticipacionRepository extends JpaRepository<Participacion, Long> {

    List<Participacion> findByLucha_Id(Long luchaId);

    @Query(value = "SELECT p.id, p.numero_equipo, p.es_ganador, p.lucha_id, g.id, g.nombre_artistico\n" +
            "FROM participaciones p \n" +
            "INNER JOIN gimmicks g \n" +
            "ON p.gimmick_id = g.id\n" +
            "WHERE p.lucha_id=?1", nativeQuery = true)
    List<ParticipacionDTO> findByLucha_Id_SQL(Long luchaId);


}
