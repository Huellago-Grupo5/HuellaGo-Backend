package pe.edu.upc.luchalibre.entities;

public enum TipoVictoria {
    PINFALL, SUMISION, DESCALIFICACION, SIN_DECISION
}
