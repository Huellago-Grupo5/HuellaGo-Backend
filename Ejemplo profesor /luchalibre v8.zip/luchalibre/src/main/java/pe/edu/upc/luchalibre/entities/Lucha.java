package pe.edu.upc.luchalibre.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "luchas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Lucha {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer ordenCartelera;

    @Enumerated(EnumType.STRING)
    private TipoLucha tipoLucha;

    private Integer minParticipantes;
    private Integer duracionMinutos;
    private Boolean estelar;

    @ManyToOne
    @JoinColumn(name = "evento_id")
    private Evento evento;


    @OneToMany(mappedBy = "lucha", fetch = FetchType.EAGER)
    private List<Participacion> participaciones;

    @OneToOne(mappedBy = "lucha", fetch = FetchType.EAGER)
    private Resultado resultado;

}
