package pe.edu.upc.luchalibre.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.luchalibre.dtos.EventoResumenDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.services.EventoService;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/lucha")
public class EventoController {

    @Autowired
    EventoService eventoService;


    //http://localhost:8080/lucha/eventos
    @GetMapping("/eventos")
    public ResponseEntity<List<Evento>> listar(){
        List<Evento> foundEventos = eventoService.listarTodo();
        if (foundEventos.isEmpty()){
            return new ResponseEntity<>(foundEventos, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(foundEventos, HttpStatus.OK);
    }

    //http://localhost:8080/lucha/eventos/resumen
    @GetMapping("/eventos/resumen")
    public ResponseEntity<List<EventoResumenDTO>> listarResumen(){
        List<EventoResumenDTO> foundEventos = eventoService.listarResumen();
        if (foundEventos.isEmpty()){
            return new ResponseEntity<>(foundEventos, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(foundEventos, HttpStatus.OK);
    }


    //http://localhost:8080/lucha/eventos/1
    @GetMapping("/eventos/{id}")
    public ResponseEntity<Evento> buscarPorId(@PathVariable("id") Long id){
        Evento foundEvento = eventoService.buscarPorId(id);
        if (foundEvento==null){
            return new ResponseEntity<>(foundEvento, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(foundEvento, HttpStatus.OK);
    }



    //http://localhost:8080/lucha/eventos
    @PostMapping("/eventos")
    public ResponseEntity<Evento> insertar(@RequestBody Evento evento){
        Evento newEvento = eventoService.insertar(evento);
        /*
        if (newEvento==null){
            return new ResponseEntity<>(newEvento, HttpStatus.NOT_ACCEPTABLE);
        }
        */
        return new ResponseEntity<>(newEvento, HttpStatus.CREATED);
    }


    //http://localhost:8080/lucha/eventos/1
    @DeleteMapping("/eventos/{id}")
    public ResponseEntity<HttpStatus> eliminar(@PathVariable("id") Long id){
        if(!eventoService.eliminar(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
        };
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //http://localhost:8080/lucha/eventos/1
    @PutMapping("/eventos")
    public ResponseEntity<Evento> actualizar(@RequestBody Evento evento){
        if(eventoService.actualizar(evento)==null) {
            return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
        };
        return new ResponseEntity<>(evento,HttpStatus.OK);
    }




}
