package pe.edu.upc.luchalibre.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "resultados")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Resultado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private TipoVictoria tipoVictoria;

    private Integer minutoFinal;
    private String observaciones;

    @OneToOne
    @JoinColumn(name = "lucha_id")
    private Lucha lucha;

}
