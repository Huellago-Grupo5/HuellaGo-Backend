package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Lucha;


public interface LuchaRepository extends JpaRepository<Lucha, Long> {

    public Lucha findLuchaByOrdenCarteleraAndEvento_Id(Integer ordenCartelera, Long eventoId);

}
