package pe.edu.upc.luchalibre.services;

import pe.edu.upc.luchalibre.dtos.EventoResumenDTO;
import pe.edu.upc.luchalibre.entities.Evento;

import java.util.List;

public interface EventoService {

    public List<Evento> listarTodo();

    public List<EventoResumenDTO> listarResumen();
    public Evento insertar(Evento evento);
    public Evento actualizar(Evento evento);

    public Evento buscarPorId(Long id);

    public Boolean eliminar(Long id);
}
