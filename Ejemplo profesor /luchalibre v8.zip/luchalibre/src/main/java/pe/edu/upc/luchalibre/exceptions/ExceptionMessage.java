package pe.edu.upc.luchalibre.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExceptionMessage {

    private Integer status; // que codigo de estatus se generó
    private String exception; // que excepcion se levantó
    private String message; // descripcion del mensaje de error personalizado
    private String requestDescription; // cual fue el Request que generó la excepcion
    private LocalDateTime timestamp; // cuando se generó la excepcion

}
