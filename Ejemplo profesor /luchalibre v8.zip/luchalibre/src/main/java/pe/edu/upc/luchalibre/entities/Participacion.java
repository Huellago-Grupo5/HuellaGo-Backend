package pe.edu.upc.luchalibre.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "participaciones")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Participacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer numeroEquipo;
    private Boolean esGanador;

    @ManyToOne
    @JoinColumn(name = "lucha_id")
    private Lucha lucha;

    @ManyToOne
    @JoinColumn(name = "gimmick_id")
    private Gimmick gimmick;


}
