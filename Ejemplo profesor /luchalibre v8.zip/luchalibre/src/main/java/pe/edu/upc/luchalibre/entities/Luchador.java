package pe.edu.upc.luchalibre.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "luchadores")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Luchador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombreReal;
    private LocalDate fechaNacimiento;
    private String pais;
    private Integer estaturaCm;
    private Double pesoKg;
    private Boolean activo;


    @OneToMany(mappedBy = "luchador", fetch = FetchType.EAGER)
    private List<Gimmick> gimmicks;



}
