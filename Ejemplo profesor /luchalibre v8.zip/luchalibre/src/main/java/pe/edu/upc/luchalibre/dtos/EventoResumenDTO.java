package pe.edu.upc.luchalibre.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventoResumenDTO {

    private Long id;
    private String nombre;
    private Integer cantidadLuchas;
    private Double duracionPromedioLuchas;

}
