package pe.edu.upc.luchalibre.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;

@RestControllerAdvice
public class ExceptionController {

    @ExceptionHandler(RepeatedValueException.class)
    @ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
    public ExceptionMessage repeatedValueException(RepeatedValueException e, WebRequest r) {
        return new ExceptionMessage(
            HttpStatus.NOT_ACCEPTABLE.value(),
            e.getClass().getSimpleName(),
            e.getMessage(),
            r.getDescription(false),
            LocalDateTime.now()
        );
    }



}
