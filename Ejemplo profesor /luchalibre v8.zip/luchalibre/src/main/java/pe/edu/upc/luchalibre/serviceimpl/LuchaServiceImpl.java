package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.dtos.LuchaDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.entities.Lucha;
import pe.edu.upc.luchalibre.entities.TipoLucha;
import pe.edu.upc.luchalibre.repositories.LuchaRepository;
import pe.edu.upc.luchalibre.services.EventoService;
import pe.edu.upc.luchalibre.services.LuchaService;

import java.util.ArrayList;
import java.util.List;

@Service
public class LuchaServiceImpl implements LuchaService {

    @Autowired
    LuchaRepository luchaRepository;


    @Autowired
    EventoService eventoService;


    @Override
    public Lucha insertar(Lucha lucha) {

        //Alternativa 1
        Evento evento=lucha.getEvento();
        for (Lucha l: evento.getLuchas()){
            if(l.getOrdenCartelera().equals(lucha.getOrdenCartelera())) {
                return null;
            }
        }

        /*
        //Alternativa 2
        Lucha luchaEncontrada = luchaRepository.findLuchaByOrdenCarteleraAndEvento_Id(lucha.getOrdenCartelera(),
                lucha.getEvento().getId());
         */

        return luchaRepository.save(lucha);
    }

    @Override
    public LuchaDTO insertarDTO(LuchaDTO luchaDTO) {

       Evento foundEvento = eventoService.buscarPorId(luchaDTO.getEventoId());
       if (foundEvento==null) {
           return null;
       }
 
       try {
           TipoLucha tipoLucha=TipoLucha.valueOf(luchaDTO.getTipoLucha());
       } catch (Exception e) {
           return null;
       }

       Lucha lucha = new Lucha(
          null,
                luchaDTO.getOrdenCartelera(),
                TipoLucha.valueOf(luchaDTO.getTipoLucha()),
                luchaDTO.getMinParticipantes(),
                luchaDTO.getDuracionMinutos(),
                luchaDTO.getEstelar(),
                foundEvento,
                null,
                null);

        Lucha newLucha = insertar(lucha);
        if (newLucha==null) {
            return null;
        }
        luchaDTO.setId(newLucha.getId());
        return luchaDTO;
    }

    @Override
    public Lucha buscarPorId(Long id) {
        return luchaRepository.findById(id).orElse(null);
    }

    @Override
    public List<LuchaDTO> listarTodoDTO() {
        List<LuchaDTO> luchasDTO = new ArrayList<>();
        List<Lucha> luchas = listarTodo();
        for (Lucha lucha: luchas) {
            LuchaDTO luchaDTO = new LuchaDTO(
                    lucha.getId(),
                    lucha.getOrdenCartelera(),
                    lucha.getTipoLucha().toString(),
                    lucha.getMinParticipantes(),
                    lucha.getDuracionMinutos(),
                    lucha.getEstelar(),
                    lucha.getEvento().getId()
            );
            luchasDTO.add(luchaDTO);
        }
        return luchasDTO;
    }

    @Override
    public List<Lucha> listarTodo() {
        return luchaRepository.findAll();
    }
}
