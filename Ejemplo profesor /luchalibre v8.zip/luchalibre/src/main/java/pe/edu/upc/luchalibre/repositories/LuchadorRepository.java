package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Luchador;


public interface LuchadorRepository extends JpaRepository<Luchador, Long> {
}
