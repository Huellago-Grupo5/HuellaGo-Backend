package pe.edu.upc.luchalibre.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.luchalibre.services.AuthorityService;

@RestController
@CrossOrigin("*")
@RequestMapping("/lucha")
public class AuthorityController {

    @Autowired
    AuthorityService authorityService;


}
