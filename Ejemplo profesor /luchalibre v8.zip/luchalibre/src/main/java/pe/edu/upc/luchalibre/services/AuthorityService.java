package pe.edu.upc.luchalibre.services;

import pe.edu.upc.luchalibre.entities.Authority;

public interface AuthorityService {
    public Authority insertar(Authority authority);

}
