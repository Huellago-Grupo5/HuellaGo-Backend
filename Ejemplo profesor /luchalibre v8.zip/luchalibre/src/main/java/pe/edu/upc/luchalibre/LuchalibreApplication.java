package pe.edu.upc.luchalibre;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import pe.edu.upc.luchalibre.entities.*;
import pe.edu.upc.luchalibre.services.AuthorityService;
import pe.edu.upc.luchalibre.services.EventoService;
import pe.edu.upc.luchalibre.services.LuchaService;
import pe.edu.upc.luchalibre.services.UserService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class LuchalibreApplication {

    public static void main(String[] args) {
        SpringApplication.run(LuchalibreApplication.class, args);
    }

    @Bean
    public CommandLineRunner startConfiguration(
          EventoService eventoService,
          LuchaService luchaService,
          AuthorityService authorityService,
          UserService userService
    ){
        return args -> {

            Authority adminAuth = authorityService.insertar(new Authority(null,"ADMIN",null));
            Authority userAuth = authorityService.insertar(new Authority(null,"USER",null));

            List<Authority> authoritiesGmorip = new ArrayList<>();
            authoritiesGmorip.add(adminAuth);
            userService.insertar(new User(null,"gmorip","1234",true,authoritiesGmorip));

            List<Authority> authoritiesRcob = new ArrayList<>();
            authoritiesRcob.add(userAuth);
            userService.insertar(new User(null,"rcob","4321",true,authoritiesRcob));


            eventoService.insertar(new Evento(null,"Triplemania", LocalDate.of(2026,5,15),
                    "AAA","Arena Mexico","CDMX","Mexico",null));

            /*
            eventoService.insertar(new Evento(null,"Triplemania", LocalDate.of(2026,5,15),
                    "AAA","Arena Mexico","CDMX","Mexico",null));
            */

            Evento evento = eventoService.buscarPorId(1L);

            luchaService.insertar(new Lucha(null,1, TipoLucha.INDIVIDUAL,2,
                    11,false,evento,null,null));


            for (Evento e : eventoService.listarTodo()) {
                System.out.println(e);
            }


        };
    }
}
