package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {

    public User findByUsername(String username);

}
