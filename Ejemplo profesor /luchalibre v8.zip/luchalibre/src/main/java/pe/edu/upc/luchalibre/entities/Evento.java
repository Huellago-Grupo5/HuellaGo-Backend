package pe.edu.upc.luchalibre.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "eventos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private LocalDate fecha;
    private String promotora;
    private String recinto;
    private String ciudad;
    private String pais;

    @ToString.Exclude
    @JsonIgnore
    @OneToMany(mappedBy = "evento", fetch = FetchType.EAGER)
    private List<Lucha> luchas;

}
