package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Evento;

import java.time.LocalDate;

public interface EventoRepository extends JpaRepository<Evento, Long> {

    //Query Methods
    public Evento findEventoByFechaAndNombre(LocalDate fecha, String nombre);


}
