package pe.edu.upc.luchalibre.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.luchalibre.dtos.ParticipacionDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.services.ParticipacionService;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/lucha")
public class ParticipacionController {

    @Autowired
    ParticipacionService participacionService;

    @GetMapping("/participaciones/lucha/{id}")
    public ResponseEntity<List<ParticipacionDTO>> listarPorLuchaId(@PathVariable("id") Long id){
        List<ParticipacionDTO> participacionDTOS = participacionService.listarPorLuchaIdDTO(id);
        if (participacionDTOS==null){
            return new ResponseEntity<>(participacionDTOS, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(participacionDTOS, HttpStatus.OK);
    }

}
