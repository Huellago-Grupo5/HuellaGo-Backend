package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.entities.Authority;
import pe.edu.upc.luchalibre.repositories.AuthorityRepository;
import pe.edu.upc.luchalibre.services.AuthorityService;

@Service
public class AuthorityServiceImpl implements AuthorityService {

    @Autowired
    AuthorityRepository authorityRepository;

    @Override
    public Authority insertar(Authority authority) {
        return authorityRepository.save(authority);
    }
}
