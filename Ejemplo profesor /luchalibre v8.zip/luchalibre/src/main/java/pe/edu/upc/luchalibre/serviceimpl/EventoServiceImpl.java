package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.dtos.EventoResumenDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.entities.Lucha;
import pe.edu.upc.luchalibre.exceptions.RepeatedValueException;
import pe.edu.upc.luchalibre.repositories.EventoRepository;
import pe.edu.upc.luchalibre.services.EventoService;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EventoServiceImpl implements EventoService {

    @Autowired
    EventoRepository eventoRepository;

    @Override
    public List<Evento> listarTodo() {
        return eventoRepository.findAll();
    }

    @Override
    public List<EventoResumenDTO> listarResumen() {
        List<EventoResumenDTO> eventoResumenDTOs = new ArrayList<>();
        List<Evento> eventos = listarTodo();

        for(Evento evento: eventos) {

            Double sumaMinutos = 0.0;
            for(Lucha lucha: evento.getLuchas()) {
                sumaMinutos = sumaMinutos + lucha.getDuracionMinutos();
            }

            EventoResumenDTO eventoResumenDTO = new EventoResumenDTO(
                    evento.getId(),
                    evento.getNombre(),
                    evento.getLuchas().size(),
                    //evento.getLuchas().stream().collect(Collectors.averagingDouble(Lucha::getDuracionMinutos))
                    sumaMinutos / evento.getLuchas().size()
            );
            eventoResumenDTOs.add(eventoResumenDTO);
        }
        return eventoResumenDTOs;

    }

    @Override
    public Evento insertar(Evento evento) {
        Evento foundEvento=eventoRepository.findEventoByFechaAndNombre(evento.getFecha(), evento.getNombre());
        if (foundEvento!=null) {
            //return null;
            throw new RepeatedValueException("El evento con nombre: "+evento.getNombre()+ " y fecha: "+evento.getFecha()+" ya fue registrado");
        }
        return eventoRepository.save(evento);
    }

    @Override
    public Evento actualizar(Evento evento) {
        Evento foundEvento= buscarPorId(evento.getId());
        if (foundEvento==null ) {
            return null;
        }

        if (evento.getNombre() == null || evento.getNombre().isEmpty()) {
            evento.setNombre(foundEvento.getNombre());
        }

        if (evento.getPais() == null || evento.getPais().isEmpty()) {
            evento.setPais(foundEvento.getPais());
        }
        if (evento.getCiudad() == null || evento.getCiudad().isEmpty()) {
            evento.setCiudad(foundEvento.getCiudad());
        }
        if (evento.getPromotora() == null || evento.getPromotora().isEmpty()) {
            evento.setPromotora(foundEvento.getPromotora());
        }
        if (evento.getRecinto() == null || evento.getRecinto().isEmpty()) {
            evento.setRecinto(foundEvento.getPromotora());
        }
        if (evento.getFecha() == null ) {
            evento.setFecha(foundEvento.getFecha());
        }

        if (eventoRepository.findEventoByFechaAndNombre(evento.getFecha(), evento.getNombre())!=null){
            return null;
        }


        return eventoRepository.save(evento);
    }

    @Override
    public Evento buscarPorId(Long id) {
        return eventoRepository.findById(id).orElse(null);
    }

    @Override
    public Boolean eliminar(Long id) {
        Evento foundEvento= buscarPorId(id);
        if (foundEvento==null || !foundEvento.getLuchas().isEmpty()  ) {
            return false;
        }
        eventoRepository.deleteById(id);
        return true;
    }

}
