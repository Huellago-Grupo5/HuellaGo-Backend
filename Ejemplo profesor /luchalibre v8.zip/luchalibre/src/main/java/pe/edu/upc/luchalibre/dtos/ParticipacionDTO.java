package pe.edu.upc.luchalibre.dtos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upc.luchalibre.entities.Gimmick;
import pe.edu.upc.luchalibre.entities.Lucha;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParticipacionDTO {

    private Long id;
    private Integer numeroEquipo;
    private Boolean esGanador;
    private Long luchaId;
    private Long gimmickId;
    private String gimmickNombreArtistico;
}
