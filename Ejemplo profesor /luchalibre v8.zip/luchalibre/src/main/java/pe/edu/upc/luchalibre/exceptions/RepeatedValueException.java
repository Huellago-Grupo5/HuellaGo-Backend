package pe.edu.upc.luchalibre.exceptions;

public class RepeatedValueException extends RuntimeException {

    public RepeatedValueException(String message) {
        super(message);
    }

    public RepeatedValueException() {
        super();
    }
}
