package pe.edu.upc.luchalibre.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfiguration {


    private static String[] LISTA_PERMIT_ALL = {

            "/swagger-ui.html",
            "/swagger-ui/**",
            "/swagger-resources/**",

            "/lucha/users/login/**",
            "/lucha/users/register/**"
    };

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration){
        return authenticationConfiguration.getAuthenticationManager();
    };

    /*

    1. Cuales seran los Request que seran evaluados para confirmar si el usuario tiene permisos
        a. AnyRequest -> Aplica al 100% de los Request
        b. RequestMatcher -> Se evalua solo los que coincidan con la ruta especifica
        c. RequestMatcher + HttpMethod -> Se evalua solo los que coincidan con la ruta especifica y con el metodo HTTP solicitado

    2. Cual es la norma/regla de autorizacion que se va aplicar a los Request a evaluar
        a. permitAll()
        b. denyAll()
        c. hasAnyAuthority()
        d. hasAuthority()
        e. hasRole()
        f. hasAnyRole()
        g. SpEL -> Spring Expression Language
        h. authenticated()



     */

    @Autowired
    JwtRequestFilter jwtRequestFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) {

        http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

        http.cors(Customizer.withDefaults());
        http.csrf(AbstractHttpConfigurer::disable);

        http.authorizeHttpRequests(
                (authorizationRegistry)->  authorizationRegistry
                //Inicio de configuracion de autorizaciones
/*
                        .requestMatchers(HttpMethod.GET,"/lucha/luchas/**").permitAll()
                        .requestMatchers(HttpMethod.POST,"/lucha/luchas/**").denyAll()
                        .requestMatchers(HttpMethod.DELETE,"/lucha/luchas/**").denyAll()
                        .requestMatchers(HttpMethod.PUT,"/lucha/luchas/**").denyAll()

                        .requestMatchers("/lucha/eventos/**").denyAll()
*/
                        .requestMatchers(LISTA_PERMIT_ALL).permitAll()

                        .requestMatchers(HttpMethod.GET,"/lucha/luchas/**").hasAnyAuthority("ADMIN","USER")
                        .requestMatchers(HttpMethod.POST,"/lucha/luchas/**").hasAnyAuthority("ADMIN")
                        .requestMatchers(HttpMethod.DELETE,"/lucha/luchas/**").hasAnyAuthority("ADMIN")
                        .requestMatchers(HttpMethod.PUT,"/lucha/luchas/**").hasAnyAuthority("ADMIN")


                        .anyRequest().authenticated()
                //Fin de configuracion de autorizaciones
        );


        http.sessionManagement(
                (sessionManager)-> sessionManager
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        );

        return http.build();
    }


}
