package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.dtos.ParticipacionDTO;
import pe.edu.upc.luchalibre.entities.Participacion;
import pe.edu.upc.luchalibre.repositories.ParticipacionRepository;
import pe.edu.upc.luchalibre.services.LuchaService;
import pe.edu.upc.luchalibre.services.ParticipacionService;

import java.util.ArrayList;
import java.util.List;

@Service
public class ParticipacionServiceImpl implements ParticipacionService {

    @Autowired
    ParticipacionRepository participacionRepository;

    @Autowired
    LuchaService luchaService;


    @Override
    public List<ParticipacionDTO> listarPorLuchaIdDTO(Long luchaId) {
        List<ParticipacionDTO> participacionesDTO = new ArrayList<>();
        List<Participacion> participaciones = participacionRepository.findByLucha_Id(luchaId);

        for (Participacion participacion: participaciones){
            ParticipacionDTO participacionDTO = new ParticipacionDTO(
                    participacion.getId(), participacion.getNumeroEquipo(), participacion.getEsGanador(),
                    participacion.getLucha().getId(),participacion.getGimmick().getId(),participacion.getGimmick().getNombreArtistico()
            );
        }
        return participacionesDTO;
    }

    @Override
    public List<ParticipacionDTO> listarPorLuchaIdDTO_Query(Long luchaId) {

        if (luchaService.buscarPorId(luchaId) == null) {
            return null;
        }
        return participacionRepository.findByLucha_Id_SQL(luchaId);
    }
}
