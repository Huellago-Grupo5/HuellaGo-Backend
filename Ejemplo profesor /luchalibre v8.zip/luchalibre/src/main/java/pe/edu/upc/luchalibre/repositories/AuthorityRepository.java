package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Authority;

public interface AuthorityRepository extends JpaRepository<Authority, Long> {
}
