package pe.edu.upc.luchalibre.services;

import org.springframework.beans.factory.annotation.Autowired;
import pe.edu.upc.luchalibre.dtos.ParticipacionDTO;
import pe.edu.upc.luchalibre.repositories.ParticipacionRepository;

import java.util.List;

public interface ParticipacionService {

    public List<ParticipacionDTO> listarPorLuchaIdDTO(Long luchaId);
    public List<ParticipacionDTO> listarPorLuchaIdDTO_Query(Long luchaId);

}
