package pe.edu.upc.luchalibre.entities;

public enum TipoLucha {
    INDIVIDUAL, PAREJAS, TERCIAS, BATALLA_REAL
}
