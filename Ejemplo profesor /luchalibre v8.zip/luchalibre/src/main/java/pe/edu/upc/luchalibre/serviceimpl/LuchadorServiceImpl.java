package pe.edu.upc.luchalibre.serviceimpl;

import pe.edu.upc.luchalibre.services.LuchadorService;

public class LuchadorServiceImpl implements LuchadorService {
}
