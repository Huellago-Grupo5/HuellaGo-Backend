package pe.edu.upc.luchalibre.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.luchalibre.dtos.TokenDTO;
import pe.edu.upc.luchalibre.entities.User;
import pe.edu.upc.luchalibre.security.JwtUtilService;
import pe.edu.upc.luchalibre.security.UserSecurity;
import pe.edu.upc.luchalibre.services.UserService;

import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
@RequestMapping("/lucha")
public class UserController {

    @Autowired
    UserService userService;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtUtilService jwtUtilService;

    @Autowired
    UserDetailsService userDetailsService;

    @PostMapping("/users/login")
    public ResponseEntity<TokenDTO> login(@RequestBody User user){
        TokenDTO tokenDTO=new TokenDTO();

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getUsername(),user.getPassword())
        );

        UserSecurity userSecurity = (UserSecurity)userDetailsService.loadUserByUsername(user.getUsername());

        tokenDTO.setToken(jwtUtilService.generateToken(userSecurity));
        tokenDTO.setId(userSecurity.getUser().getId());
        tokenDTO.setAuthorities(userSecurity.getUser().getAuthorities().stream().map(
                authority ->  authority.getName())
                .collect(Collectors.joining(";","",""))
        );

        return new ResponseEntity<>(tokenDTO, HttpStatus.OK);
    }

}
