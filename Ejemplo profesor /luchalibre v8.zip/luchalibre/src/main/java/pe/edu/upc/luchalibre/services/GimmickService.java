package pe.edu.upc.luchalibre.services;

public interface GimmickService {
}
