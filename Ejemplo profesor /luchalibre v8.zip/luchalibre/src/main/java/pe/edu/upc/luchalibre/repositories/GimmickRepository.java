package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Gimmick;

public interface GimmickRepository extends JpaRepository<Gimmick, Long> {
}
