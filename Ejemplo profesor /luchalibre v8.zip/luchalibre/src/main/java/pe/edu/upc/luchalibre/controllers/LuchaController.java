package pe.edu.upc.luchalibre.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.luchalibre.dtos.LuchaDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.services.LuchaService;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/lucha")
public class LuchaController {

    @Autowired
    LuchaService luchaService;

    //http://localhost:8080/lucha/luchas
    @GetMapping("/luchas")
    public ResponseEntity<List<LuchaDTO>> listar(){
        List<LuchaDTO> foundLuchas = luchaService.listarTodoDTO();
        if (foundLuchas.isEmpty()){
            return new ResponseEntity<>(foundLuchas, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(foundLuchas, HttpStatus.OK);
    }

    //http://localhost:8080/lucha/luchas
    @PostMapping("/luchas")
    public ResponseEntity<LuchaDTO> insertar(@RequestBody LuchaDTO luchaDTO){
        LuchaDTO newLuchaDTO = luchaService.insertarDTO(luchaDTO);
        if (newLuchaDTO==null){
            return new ResponseEntity<>(newLuchaDTO, HttpStatus.NOT_ACCEPTABLE);
        }
        return new ResponseEntity<>(newLuchaDTO, HttpStatus.CREATED);
    }

}
