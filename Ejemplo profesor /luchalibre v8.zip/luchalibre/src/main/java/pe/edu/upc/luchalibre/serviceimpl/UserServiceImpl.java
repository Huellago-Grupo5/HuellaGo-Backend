package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.entities.User;
import pe.edu.upc.luchalibre.repositories.UserRepository;
import pe.edu.upc.luchalibre.services.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;


    @Override
    public User insertar(User user) {
        user.setPassword( new BCryptPasswordEncoder().encode(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public User buscarPorUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
