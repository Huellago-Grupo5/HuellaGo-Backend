package pe.edu.upc.luchalibre.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "gimmicks")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Gimmick {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombreArtistico;
    private String alineacion;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private Boolean activo;

    @ManyToOne
    @JoinColumn(name = "luchador_id")
    private Luchador luchador;

    @OneToMany(mappedBy = "gimmick", fetch = FetchType.EAGER)
    private List<Participacion> participaciones;


}
