package pe.edu.upc.luchalibre.services;

import pe.edu.upc.luchalibre.dtos.LuchaDTO;
import pe.edu.upc.luchalibre.entities.Evento;
import pe.edu.upc.luchalibre.entities.Lucha;

import java.util.List;

public interface LuchaService {

    public Lucha insertar(Lucha lucha);
    public LuchaDTO insertarDTO(LuchaDTO luchaDTO);
    public Lucha buscarPorId(Long id);

    public List<LuchaDTO> listarTodoDTO();
    public List<Lucha> listarTodo();



}
