package pe.edu.upc.luchalibre.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.luchalibre.entities.Resultado;

public interface ResultadoRepository extends JpaRepository<Resultado, Long> {
}
