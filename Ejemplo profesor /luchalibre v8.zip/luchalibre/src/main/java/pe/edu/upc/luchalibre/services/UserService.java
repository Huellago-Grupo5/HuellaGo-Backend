package pe.edu.upc.luchalibre.services;

import pe.edu.upc.luchalibre.entities.User;

public interface UserService {
    public User insertar(User user);
    public User buscarPorUsername(String username);
}
