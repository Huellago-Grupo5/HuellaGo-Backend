package pe.edu.upc.luchalibre.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import pe.edu.upc.luchalibre.entities.User;
import pe.edu.upc.luchalibre.security.UserSecurity;
import pe.edu.upc.luchalibre.services.UserService;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserService userService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userService.buscarPorUsername(username);
        //Validacion si user es null
        return new UserSecurity(user);

    }


}
