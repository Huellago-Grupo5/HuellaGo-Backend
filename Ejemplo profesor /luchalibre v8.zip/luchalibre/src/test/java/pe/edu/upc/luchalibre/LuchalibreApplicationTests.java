package pe.edu.upc.luchalibre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuchalibreApplicationTests {

    @Test
    void contextLoads() {
    }

}
